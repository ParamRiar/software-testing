//
//  GameViewController.swift
//  SpriteKitSimpleGame
//
//  Created by Main Account on 9/30/16.
//  Copyright © 2016 Razeware LLC. All rights reserved.
//

import UIKit
import SpriteKit
 
class GameViewController: UIViewController {
 var datapass = ""
    var seconddata = ""
  override func viewDidLoad() {
    
    super.viewDidLoad()
    var passString = ""
    
    
    if(datapass == ""){
    
     passString = seconddata
    }else{
        passString = datapass
    }
    
    
    let scene = GameScene(size: view.bounds.size)
    
   // let data =  GameScene(passingString: passString)
    
    let skView = view as! SKView
    skView.showsFPS = true
    skView.showsNodeCount = true
    skView.ignoresSiblingOrder = true
    scene.scaleMode = .resizeFill
    skView.presentScene(scene)
  }
 
  override var prefersStatusBarHidden: Bool {
    return true
  }
 
}
