//
//  firstViewController.swift
//  SpriteKitSimpleGame
//
//  Created by MacStudent on 2017-06-02.
//  Copyright © 2017 Razeware LLC. All rights reserved.
//

import UIKit

class firstViewController: UIViewController {

    var playerA = "PLAYER1"
    var playerB = "PLAYER2"
    
    
    
    @IBAction func player2(_ sender: Any) {
        
        
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "gameview") as! GameViewController
        
    nextViewController.seconddata = playerB
        self.present(nextViewController, animated:true, completion:nil)
        
        
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
    }

    
    
    @IBAction func player1(_ sender: UIButton) {
        
        
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "gameview") as! GameViewController
       nextViewController.datapass = playerA
        
        self.present(nextViewController, animated:true, completion:nil)
        
        
    }
    
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
